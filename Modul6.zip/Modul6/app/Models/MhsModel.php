<?php

namespace App\Models;

use CodeIgniter\Model;

class MhsModel extends Model
{
    protected $nama = "Muhammad Akbar";
    protected $nim = "2110817110001";
    protected $prodi = "Teknologi Informasi";
    protected $cita_cita = "Entrepreneur";
    protected $hobi = "basket,main game";
    protected $skill = "Operator";
    protected $motivasi = "man jadda wajada";





    protected $foto1 = "Foto.jpg";

    public function getNama()
    {
        return $this->nama;
    }
    public function getNim()
    {
        return $this->nim;
    }
    public function getProdi()
    {
        return $this->prodi;
    }
    public function getcita_cita()
    {
        return $this->cita_cita;
    }
    public function gethobi()
    {
        return $this->nim;
    }
    public function getSkill()
    {
        return $this->skill;
    }
    public function getMotivasi()
    {
        return $this->motivasi;
    }

    public function getFoto1()
    {
        return $this->foto1;
    }
}